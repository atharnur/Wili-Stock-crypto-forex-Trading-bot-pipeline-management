📄 KPI_Definitions.md

CPI, SPI

Scope Stability Index

Defect Leakage

📄 Metrics_Dashboard_Logic.md

Real-time delivery KPIs

Risk indicators

📄 Lessons_Learned.md

Early compliance reduces cost

Scope discipline saves startups

Visibility builds trust
