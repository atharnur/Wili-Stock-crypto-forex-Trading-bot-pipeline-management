📄 Stakeholder_Register.md
Stakeholder	Role	Influence
Founder	Sponsor	High
Compliance Officer	Regulatory	High
TPM	Delivery Owner	High
Dev Lead	Execution	Medium

📄 RACI_Matrix.md
Activity	TPM	Dev	QA	Founder
Planning	R	   A	C	    C
Delivery	A	   R	C	    I

📄 Communication_Plan.md

Weekly sprint demo

Weekly KPI report

Monthly steering meeting

📄 Steering_Committee_Model.md

Founder

TPM

Delivery Head

Compliance (as needed)

📄 Decision_Escalation_Framework.md

Sprint-level → TPM

Budget/scope → Steering Committee
