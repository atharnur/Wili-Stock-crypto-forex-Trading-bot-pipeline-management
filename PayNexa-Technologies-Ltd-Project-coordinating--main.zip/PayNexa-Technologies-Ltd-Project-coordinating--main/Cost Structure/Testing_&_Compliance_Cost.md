# Testing & Compliance Cost

## Quality Activities
- Alpha Testing: USD 1,000
- Beta Support: USD 1,200
- UAT Workshops: USD 1,500
- Load & Performance Testing: USD 1,800
- Security Audit (Basic): USD 2,500

Total Quality & Compliance Cost: **USD 8,000**
