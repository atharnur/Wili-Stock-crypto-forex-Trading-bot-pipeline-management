# Budget Baseline

Baseline Approval Date: Project Kickoff + Week 2  
Baseline Owner: Technical Project Manager

## Baseline Rules
- Any variance > ±5% requires escalation
- Scope changes must map to budget delta
- Contingency usage requires justification

Baseline Locked Budget: **USD 82,220**
