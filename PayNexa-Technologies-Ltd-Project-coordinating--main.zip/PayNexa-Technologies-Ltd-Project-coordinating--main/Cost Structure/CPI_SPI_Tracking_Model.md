# CPI & SPI Tracking Model

- CPI = Earned Value / Actual Cost
- SPI = Earned Value / Planned Value

Tracking Cadence:
- Weekly sprint review
- Monthly financial review

Escalation Trigger:
- CPI < 0.95
- SPI < 0.90
